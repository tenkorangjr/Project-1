<?php
// Include config file
require_once "config.php";
 
// Define variables and initialize with empty values
$uname = $email = $password = "";
$uname_err = $email_err =$password_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Validate name
    if(empty(trim($_POST["uname"]))){
        $uname_err = "Please enter a Full name!";
    } else{
        $uname = trim($_POST["uname"]);
    }

    // Validate email
    if(empty(trim($_POST["email"]))){
        $email_err = "Please enter a email.";
    } else{
        // Prepare a select statement
        $sql = "SELECT id FROM users WHERE email = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_email);
            
            // Set parameters
            $param_email = trim($_POST["email"]);
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                /* store result */
                mysqli_stmt_store_result($stmt);
                
                if(mysqli_stmt_num_rows($stmt) == 1){
                    $email_err = "This email is already taken.";
                } else{
                    $email = trim($_POST["email"]);
                }
            } else{
                echo "Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
    // Validate password
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter a password.";     
    } elseif(strlen(trim($_POST["password"])) < 6){
        $password_err = "Password must have at least 6 characters.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Check input errors before inserting in database
    if(empty($uname_err) && empty($email_err) && empty($password_err)){
        
        // Prepare an insert statement
        $sql = "INSERT INTO users (uname, email, password) VALUES (?, ?, ?)";
         
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "sss", $param_uname, $param_email, $param_password);
            
            // Set parameters
            $param_uname = $uname;
            $param_email = $email;
            $param_password = password_hash($password, PASSWORD_DEFAULT); // Creates a password hash
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Redirect to login page
                header("location: sign in.php");
            } else{
                echo "Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
    // Close connection
    mysqli_close($link);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign up | KINX</title> 
    <link rel="shortcut icon" href="Kasoa final.png">
</head>
<body>
    <h1 style="text-align: center; font-family: Calibri;" class="klogo"> <img src="Kasoa final.png" width="50" height="90">INX </h1>

    <h4 style="text-align: center; font-family: Calibri; background-color: darkkhaki;";>Sign up to join the community of achievers NOW!!!</h4>
    
    <form style="text-align: center; font-family: Calibri; font-size: 120%;" action="" method="post">
        <label for="uname">Full name: </label>
        <input type="text" id="uname" name="uname" class="inputsup"><br><br>
        <label for="email">Email address: </label>
        <input type="email" id="email" name="email" class="inputsup"><br><br>
        <label for="password">Password: </label>
        <input type="password" id="password" name="password" class="inputsup"><br><br>
        <input type="submit" value="Sign Up" style="font-size:110%;">
    </form>
</body>
</html>