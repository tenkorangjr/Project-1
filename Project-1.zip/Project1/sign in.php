<?php

include 'config.php';

session_start();

error_reporting(0);

if (isset($_SESSION['username'])) {
    header("Location: kinx.php");
}

if (isset($_POST['submit'])) {
	$email = $_POST['email'];
	$password = md5($_POST['password']);

	$sql = "SELECT * FROM users WHERE email='$email' AND password='$password'";
	$result = mysqli_query($link, $sql);
	if ($result->num_rows > 0) {
		$row = mysqli_fetch_assoc($result);
		$_SESSION['username'] = $row['username'];
		header("Location: kinx.php");
	} else {
		echo "<script>alert('Wrong email or password!')</script>";
	}
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" href = "Kasoa final.png">
</head>
<body>
    <h1 style="text-align: center; font-family: Calibri;">
        <img src="Kasoa final.png" width="50" height="90">INX
    </h1><br><br>
    <h3 style="font-size:200%; font-family:calibri;"> Login</h3><br>
    <h4 style="font-family:calibri; background-color: darkkhaki;"> To log in, please enter your email and password</h4>

    <form style="font-family: Calibri; font-size: 120%;" action="" method="post">
        <label for="email"> Email address: </label>
        <input type="email" id="email" placeholder ="Email"><br>
        <label for="password">Password: </label>
        <input class="input" type="password" id="password" placeholder="Password">
        <a href="forgotpassword.html" style="font-size: 80%;">Forgot password?</a><br><br>
        <input type="submit" value="Login" style="font-size:110%;"><br><br>
        <h3 style="font-size: 90%;">Don't have an account? <a href="sign up.php">Sign up</a></h3>
    </form>
    
</body>
</html>