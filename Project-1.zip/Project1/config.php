<?php

	$server = "localhost";
	$user = "root";
	$email = "";
	$uname = "";
	$pass = "";
	$database = "project1";

	$link = mysqli_connect($server, $user, $pass, $database);

    if(!$link) {
        die("<script>alert('Connection failed. ')</script>");
    }
    
?>