<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home | Kinx</title>
    <link rel="shortcut icon" href = "Kasoa final.png">
    <link rel="stylesheet" href="style.css">
</head>
<body style="font-family:'Calibri';">
    <h1>Welcome to Kinx</h1>
    <h3>Thank you for trying my webpage. Kindly logout!!!</h3>

    <input type="submit" value="Log Out" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post"">

</body>
</html>